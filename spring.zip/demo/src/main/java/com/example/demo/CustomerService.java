package com.example.demo;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CustomerService {
	@Autowired
	public CustomerRepository customerRepository;
	public void generateCustomer(Customer cust) {
		System.out.println(cust.getCustomerId());
		System.out.println(cust.getCustomerName());
		System.out.println(cust.getCustomerPhone());
		System.out.println(cust.getCustomerEmail());
		
		customerRepository.save(cust);
		
	}
	public List<Customer> getAllCustomer() {
		
		return customerRepository.findAll();
		
	}
	public Customer getCustomerById(Long cId) {
		Optional<Customer> oCust=customerRepository.findById(cId);
		return oCust.get();
	}
	public void deleteCustomerById(Long cId) {
		customerRepository.deleteById(cId);
	}
	public void updateCustomerById(Long cId, Customer c) {
		Optional<Customer> oCust=customerRepository.findById(cId);
		if(oCust.isPresent())
		{
			c.setCustomerId(cId);
			customerRepository.save(c);
		}
		
	}
}
