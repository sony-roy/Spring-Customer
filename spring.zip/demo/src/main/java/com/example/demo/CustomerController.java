package com.example.demo;


import java.util.List;

import org.hibernate.annotations.UpdateTimestamp;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CustomerController {
	
	@Autowired
	CustomerService customerService;
	@PostMapping(value="/customer/create")
	
	public void createCustomer(@RequestBody Customer cust) {
		customerService.generateCustomer(cust);
	}
	
	@GetMapping(value="/customer/customers")
	public List<Customer> getAllCustomer()
	{
		
		return customerService.getAllCustomer();
	}
	@GetMapping(value="/customer/{customerId}")
	public Customer getCustomerById(@PathVariable("customerId") Long cId)
	{
		return customerService.getCustomerById(cId);
		
	}
	@DeleteMapping("/customer/delete/{CustomerId}")
	public void deleteCustomerById(@PathVariable("CustomerId") Long cId)
	{
		customerService.deleteCustomerById(cId);
	}
	
	@PutMapping("/customer/update/{customerId}")
	public Customer updateCustomerById(@PathVariable("customerId") Long cId,@RequestBody Customer c)
	{
		customerService.updateCustomerById(cId,c);
		return customerService.getCustomerById(cId);
	}
}
